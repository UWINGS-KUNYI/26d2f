package app.test.com.takepictrueinbackground;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends Activity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //检查相机权限，未获取权限的提示用户获取，已获取权限则检查是否设置允许在其他应用上显示的权限
        if(!myCheckPermission(this,android.Manifest.permission.CAMERA))
        {
            openPermission(this,android.Manifest.permission.CAMERA,0x101);
        }
        else
        {
            setDrawOverlays();
        }
    }

    @SuppressLint("NewApi")
    private void setDrawOverlays()
    {
        //检查是否设置允许在其他应用上显示的权限，未设置跳转到设置界面，已设置则启动服务
        if (! Settings.canDrawOverlays(MainActivity.this)) {

            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setMessage("为更好显示通知，请设置允许出现在其他应用上！是否前往设置？");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "是", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    //跳转设置
                    startActivityForResult(intent,0x102);
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "否", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {

                }
            });
            alertDialog.show();

        }
        else
        {

            startTakePictrueService();

        }
    }

    private void startTakePictrueService()
    {
        try
        {
            startService(new Intent(this, TakePictrueService.class));
        }catch (Exception e){}
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        //用户设置允许在其他应用上显示的权限，启动服务
        if(requestCode == 0x102)
        {
            startTakePictrueService();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
        {
            //用户设置允许使用相机的权限，则检查是否设置允许在其他应用上显示的权限
            if(requestCode == 0x101)
            {
                setDrawOverlays();
            }
        }
    }

    private void openPermission(Activity activity, String permission, int requestCode)
    {
        try
        {
            ActivityCompat.requestPermissions(activity, new String[]{permission}, requestCode);
        }catch (Exception e){}
    }


    private boolean myCheckPermission(Context context, String permission)
    {
        try
        {
            if (ContextCompat.checkSelfPermission(context, permission)
                    == PackageManager.PERMISSION_GRANTED)
            {
                return true;
            }
        }
        catch (Exception e){}
        return false;
    }
}
